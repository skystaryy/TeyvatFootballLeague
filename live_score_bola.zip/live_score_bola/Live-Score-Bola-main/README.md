# live score bola
![image](https://github.com/faridfadhlan666/Live-Score-Bola/assets/162896380/1d043f6a-6071-4381-85ad-e9cfd3bbbdf4)

![image](https://github.com/faridfadhlan666/Live-Score-Bola/assets/162896380/161acadb-41cb-47f2-8c93-d05a6b251139)


A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
